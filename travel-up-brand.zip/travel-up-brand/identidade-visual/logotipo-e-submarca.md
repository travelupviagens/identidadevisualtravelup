# Logotipo e submarca — Travel Up

## Confiabilidade deste inventário

**Alta.** Cada uma das 19 variações foi conferida abrindo o `.svg` e lendo o hex declarado no traçado e no retângulo de fundo. A tabela abaixo descreve o que cada arquivo realmente contém, não o que o nome original dizia.

## O logotipo

Wordmark `travel up`, em caixa baixa, com um ícone de avião integrado à assinatura do `up`. A palavra é desenhada em Bricolage Grotesque.

Personalidade que o logotipo carrega, conforme o manual: confiável, minimalista, objetiva e amigável.

Proporção da arte: todos os arquivos, SVG e PNG, vêm em `viewBox="0 0 800 450"`, ou seja, 16:9. O logotipo é centralizado dentro dessa área, com margem generosa em volta. Se precisar do logotipo ajustado ao próprio contorno, recorte a partir do SVG ou trabalhe do `.ai` em `assets/editaveis/`.

## A submarca

Versão compacta e simplificada do logo principal, desenvolvida para reforçar a identidade visual em diferentes aplicações. Usa apenas o elemento `up` com o ícone de avião, mantendo elementos minimalistas para preservar a essência da marca.

Quando usar submarca em vez do logotipo completo:

- Foto de perfil de rede social, favicon, avatar de WhatsApp.
- Selo em canto de peça onde o wordmark já apareceu.
- Brinde, adesivo, aplicação pequena onde `travel up` ficaria ilegível.
- Marca d'água discreta.

Quando usar o logotipo completo:

- Primeira aparição da marca em qualquer peça.
- Capa de apresentação comercial.
- Cabeçalho de orçamento, proposta, e-mail.
- Cartão de visitas.

## Inventário completo

19 variações, cada uma em `.svg` (em `assets/logos/svg/`) e `.png` 1600x900px (em `assets/logos/png/`).

### Logotipo completo — 10 variações

| Arquivo (sem extensão) | Cor do logo | Cor do fundo | Usar quando |
|---|---|---|---|
| `logo-azul-principal-fundo-transparente` | `#24356D` | transparente | **Versão padrão.** Sobre qualquer fundo claro. |
| `logo-azul-principal-fundo-branco` | `#24356D` | `#F2F2F2` | Quando precisar do fundo sólido claro embutido. |
| `logo-azul-principal-fundo-azul-claro` | `#24356D` | `#A5D9EC` | Peça com fundo de destaque em azul claro. |
| `logo-azul-secundario-fundo-transparente` | `#27499A` | transparente | Variação mais viva, contexto digital leve. |
| `logo-azul-claro-fundo-transparente` | `#A5D9EC` | transparente | Sobre fundo azul escuro ou foto escura. |
| `logo-verde-terciario-fundo-transparente` | `#465E74` | transparente | Contexto neutro, sóbrio, menos saturado. |
| `logo-preto-fundo-transparente` | `#282828` | transparente | Impressão monocromática, fax, documento P&B. |
| `logo-branco-fundo-azul-principal` | `#FFFFFF` | `#25356D` | Capa institucional, fundo escuro embutido. |
| `logo-branco-fundo-azul-secundario` | `#FFFFFF` | `#27499A` | Alternativa de capa, azul mais vivo. |
| `logo-branco-fundo-verde-terciario` | `#FFFFFF` | `#465E74` | Capa em tom neutro escuro. |

Falta na biblioteca: **não existe logotipo completo em branco com fundo transparente.** Só a submarca tem essa versão. Para aplicar o logotipo branco sobre foto ou sobre um fundo escuro que não seja `#25356D`, `#27499A` ou `#465E74`, você precisa gerar o arquivo a partir do `.ai`, ou editar o SVG de `logo-branco-fundo-azul-principal` removendo a linha `<rect class="cls-3" ... />`.

### Submarca — 9 variações

| Arquivo (sem extensão) | Cor da marca | Cor do fundo | Usar quando |
|---|---|---|---|
| `submarca-azul-principal-fundo-transparente` | `#24356D` | transparente | **Versão padrão da submarca.** |
| `submarca-azul-principal-fundo-azul-claro` | `#24356D` | `#A5D9EC` | Avatar com fundo azul claro. |
| `submarca-azul-secundario-fundo-transparente` | `#27499A` | transparente | Variação mais viva. |
| `submarca-azul-claro-fundo-transparente` | `#A5D9EC` | transparente | Sobre fundo escuro. |
| `submarca-verde-terciario-fundo-transparente` | `#465E74` | transparente | Contexto neutro. |
| `submarca-preto-fundo-transparente` | `#282828` | transparente | Monocromático. |
| `submarca-branca-fundo-transparente` | `#F2F2F2` | transparente | **Sobre foto ou fundo escuro arbitrário.** |
| `submarca-branca-fundo-azul-principal` | `#F2F2F2` | `#25356D` | Avatar padrão de rede social. |
| `submarca-branca-fundo-verde-terciario` | `#F2F2F2` | `#465E74` | Avatar em tom neutro escuro. |

## Escolha rápida

Se você é um agente gerando uma peça e precisa decidir em um passo:

- Fundo claro, logotipo completo → `logo-azul-principal-fundo-transparente`
- Fundo escuro, logotipo completo → `logo-azul-claro-fundo-transparente`
- Avatar ou ícone → `submarca-branca-fundo-azul-principal`
- Marca d'água sobre foto → `submarca-branca-fundo-transparente`
- Impressão em preto e branco → `logo-preto-fundo-transparente`

## Erros de rotulagem nos arquivos originais

O estúdio entregou três arquivos com nome que não corresponde ao conteúdo. Os arquivos deste repositório já estão corrigidos. Se você for buscar algo direto no Drive, atenção a isto:

| Nome original do estúdio | Conteúdo real | Nome neste repositório |
|---|---|---|
| `Logo Azul Secundário FundoTransparente` | logo em `#24356D`, que é o azul **principal** | `logo-azul-principal-fundo-transparente` |
| `Submarca Verde Fundo Verde Terciário` | submarca **branca** `#F2F2F2` sobre fundo `#465E74` | `submarca-branca-fundo-verde-terciario` |
| `Logo Fundo Azul Principal` / `Submarca Branca Fundo Azul Principal` | usam `#25356D` no fundo, não `#24356D` | mantidos, variação documentada em `cores.md` |

Note que os nomes `Logo Azul Secundário Fundo Transparente` e `Logo Azul Secundário FundoTransparente` diferiam só por um espaço e eram arquivos diferentes. Um era de fato o azul secundário, o outro era o principal.

## Mapeamento completo de nomes

Para rastrear qualquer arquivo até a entrega original do estúdio.

### Logotipo — origem `4 - Logotipo/SVG/` e `4 - Logotipo/PNG/`

| Original | Neste repositório |
|---|---|
| `Logo Azul Principal Fundo Branco` | `logo-azul-principal-fundo-branco` |
| `Logo Azul Secundário FundoTransparente` | `logo-azul-principal-fundo-transparente` |
| `Logo Azul Secundário Fundo Transparente` | `logo-azul-secundario-fundo-transparente` |
| `Logo Azul Claro Fundo Transparente` | `logo-azul-claro-fundo-transparente` |
| `Logo Verde Terciário Fundo Transparente` | `logo-verde-terciario-fundo-transparente` |
| `Logo Preto Fundo Transparente` | `logo-preto-fundo-transparente` |
| `Logo Azul Fundo Azul Claro` | `logo-azul-principal-fundo-azul-claro` |
| `Logo Fundo Azul Principal` | `logo-branco-fundo-azul-principal` |
| `Logo Fundo Azul Secundário` | `logo-branco-fundo-azul-secundario` |
| `Logo Branco Fundo Verde Terciário` | `logo-branco-fundo-verde-terciario` |

### Submarca — origem `4 - Logotipo/SVG/` (SVG) e `5 - Submarca/` (PNG)

| Original | Neste repositório |
|---|---|
| `Submarca Principal Fundo Transparente` | `submarca-azul-principal-fundo-transparente` |
| `Submarca Secundária Fundo Transparente` | `submarca-azul-secundario-fundo-transparente` |
| `Submarca Azul Claro Fundo Transparente` | `submarca-azul-claro-fundo-transparente` |
| `Submarca Verde Fundo Transparente` | `submarca-verde-terciario-fundo-transparente` |
| `Submarca Preto Fundo Transparente` | `submarca-preto-fundo-transparente` |
| `Submarca Branca Fundo Transparente` | `submarca-branca-fundo-transparente` |
| `Submarca Azul Fundo Azul Claro` | `submarca-azul-principal-fundo-azul-claro` |
| `Submarca Branca Fundo Azul Principal` | `submarca-branca-fundo-azul-principal` |
| `Submarca Verde Fundo Verde Terciário` | `submarca-branca-fundo-verde-terciario` |

## Regras de aplicação

Estas regras não estão escritas no manual de identidade. São recomendação prática coerente com o posicionamento minimalista da marca. Trate como padrão sensato, não como norma do estúdio.

- **Área de proteção:** manter em volta do logotipo um espaço livre equivalente à altura da letra `u` do wordmark. Nenhum outro elemento entra nessa área.
- **Tamanho mínimo:** o wordmark completo não deve ser aplicado com menos de 24px de altura em tela, nem 12mm de largura em impressão. Abaixo disso, use a submarca.
- **Não fazer:** distorcer a proporção, rotacionar, aplicar sombra, contorno ou brilho, trocar a cor do logotipo por uma cor fora da paleta, aplicar sobre fundo de baixo contraste, recriar o wordmark digitando `travel up` em Bricolage Grotesque (o desenho tem ajustes, use o arquivo).

## Arquivo editável

`assets/editaveis/travel-up-arquivo-editavel.ai` (~1,5 MB) contém o vetor original editável. Use quando precisar de uma variação que não existe na biblioteca, como o logotipo completo em branco sobre transparente.

O `.eps` equivalente (~8,9 MB) e o mockup `First View - Travel Up.psd` (~174 MB) não estão versionados e ficam no Google Drive.
