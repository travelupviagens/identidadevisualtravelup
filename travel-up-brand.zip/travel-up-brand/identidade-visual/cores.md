# Paleta de cores — Travel Up

## Confiabilidade destes valores

**Alta.** Os hex abaixo foram lidos direto do código-fonte dos arquivos `.svg` em `assets/logos/svg/`, que são exportação vetorial do arquivo original do estúdio. São valores de especificação declarados no arquivo, não amostragem de pixel de imagem.

Uma versão anterior desta paleta havia sido obtida por amostragem de pixel de uma imagem rasterizada e estava errada em todas as seis cores. Se algum material da Travel Up usa `#223C74`, `#1C54A6`, `#7DD1E3`, `#335F76`, `#181C1E` ou `#ECECEC`, está com cor incorreta e deve ser atualizado.

Ressalva conhecida: o manual em PDF é CMYK para pré-impressão (PDF/X-1). Os valores abaixo são RGB, corretos para uso digital, que é onde a marca vive. Para impressão, converter a partir destes valores ou pedir a especificação CMYK ao estúdio.

## Cores da marca

| Nome | Hex | RGB | Papel |
|---|---|---|---|
| Azul principal | `#24356D` | 36, 53, 109 | Cor primária da marca. Fundo institucional, logotipo sobre fundo claro, títulos. |
| Azul secundário | `#27499A` | 39, 73, 154 | Variação mais viva do azul. Links, estados ativos, fundo alternativo. |
| Azul claro | `#A5D9EC` | 165, 217, 236 | Cor de destaque e respiro. Fundo de seção, realce, logotipo sobre fundo escuro. |
| Verde terciário | `#465E74` | 70, 94, 116 | Azul acinzentado de apoio. Texto secundário, bordas, fundo neutro escuro. |
| Preto | `#282828` | 40, 40, 40 | Texto corrido em fundo claro. Não usar `#000000`. |
| Branco de marca | `#F2F2F2` | 242, 242, 242 | Fundo claro padrão. Não usar `#FFFFFF` puro como fundo de peça. |

"Verde terciário" é o nome que o estúdio deu ao `#465E74` nos arquivos de origem. A cor é um azul acinzentado, não um verde. O nome foi mantido para bater com o nome dos arquivos, mas não descreva a cor como verde em texto para cliente.

## Variação conhecida no azul principal

Dois arquivos usam `#25356D` no retângulo de fundo em vez de `#24356D`: `logo-branco-fundo-azul-principal` e `submarca-branca-fundo-azul-principal`. Diferença de 1 no canal vermelho, imperceptível a olho nu, provável arredondamento na exportação.

**Use sempre `#24356D`.** É o valor que aparece no próprio traçado do logotipo, não só em fundo.

## Uso de branco puro

`#FFFFFF` aparece nos arquivos em duas situações, ambas legítimas:

- Como cor do logotipo em versões negativas (`logo-branco-fundo-azul-principal`, `logo-branco-fundo-azul-secundario`, `logo-branco-fundo-verde-terciario`).
- Como parada final transparente dos gradientes internos do logotipo.

Há uma inconsistência nos arquivos de origem: os logotipos negativos usam `#FFFFFF` e as submarcas negativas usam `#F2F2F2`. Para material novo, padronize em `#F2F2F2`.

## Contraste (WCAG 2.1)

Razões calculadas. AA para texto normal exige 4.5:1, AAA exige 7:1.

| Combinação | Razão | Veredito |
|---|---|---|
| `#282828` sobre `#FFFFFF` | 14.74:1 | AAA |
| `#24356D` sobre `#FFFFFF` | 11.63:1 | AAA |
| `#24356D` sobre `#F2F2F2` | 10.39:1 | AAA |
| `#FFFFFF` sobre `#24356D` | 11.63:1 | AAA |
| `#27499A` sobre `#FFFFFF` | 8.38:1 | AAA |
| `#27499A` sobre `#F2F2F2` | 7.49:1 | AAA |
| `#24356D` sobre `#A5D9EC` | 7.61:1 | AAA |
| `#FFFFFF` sobre `#27499A` | 8.38:1 | AAA |
| `#465E74` sobre `#FFFFFF` | 6.74:1 | AA, reprova AAA |
| `#FFFFFF` sobre `#465E74` | 6.74:1 | AA, reprova AAA |
| `#465E74` sobre `#F2F2F2` | 6.02:1 | AA, reprova AAA |
| `#A5D9EC` sobre `#FFFFFF` | 1.53:1 | **Reprova. Nunca use.** |

Regras que saem daí:

- Azul claro `#A5D9EC` é cor de fundo ou de elemento gráfico, **nunca cor de texto sobre fundo claro**.
- Texto em azul claro só sobre azul principal (7.61:1) ou azul secundário.
- Verde terciário `#465E74` serve para texto corrido, mas prefira `#282828` quando a legibilidade importar.

## Gradientes

Os gradientes que existem dentro dos arquivos de logo **não são um gradiente de marca**. São um fade da própria cor do logotipo para transparente, aplicado no rastro do avião, para dar efeito de brilho. Exemplo, do `logo-azul-principal-fundo-branco`:

```
linear-gradient de #24356D (opacidade 1) → #495785 (0.83) → #A8AFC5 (0.39) → transparente
```

Esse fade é interno ao desenho do logotipo. Não o reproduza como elemento gráfico de peça.

Para um gradiente de marca em material novo, o par natural é azul principal → azul claro:

```css
background: linear-gradient(135deg, #24356D 0%, #A5D9EC 100%);
```

Não há confirmação de que esse gradiente esteja especificado no manual de identidade. Trate como decisão de aplicação, não como regra de marca, e valide com Paula antes de usar em peça institucional.

## Cores proibidas

Diretriz do briefing original: evitar cores muito fortes e quentes, para não remeter a varejo.

Não introduzir em peça da marca, nem como cor de destaque, alerta ou botão: vermelho, laranja, amarelo, magenta, verde saturado. Se precisar de um estado de erro ou alerta em interface, use o azul escuro com peso tipográfico em vez de cor quente, ou traga a decisão para Paula.

## CSS pronto

```css
:root {
  --tu-azul-principal:  #24356D;
  --tu-azul-secundario: #27499A;
  --tu-azul-claro:      #A5D9EC;
  --tu-verde-terciario: #465E74;
  --tu-preto:           #282828;
  --tu-branco:          #F2F2F2;
}
```
