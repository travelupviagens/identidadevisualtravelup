# Tipografia — Travel Up

## Confiabilidade destes valores

**Alta.** Nome, versão, licença e eixos variáveis foram lidos das tabelas internas (`name`, `fvar`) dos arquivos `.ttf` em `assets/fontes/`. A atribuição de qual fonte é título e qual é corpo vem do manual de identidade.

## Fonte primária: Bricolage Grotesque

Uso: títulos, destaques, o wordmark.

| Campo | Valor |
|---|---|
| Família | Bricolage Grotesque |
| Arquivo | `assets/fontes/bricolage-grotesque/BricolageGrotesque-VariableFont_opsz,wdth,wght.ttf` |
| Versão | 1.001 (gftools 0.9.33.dev8) |
| Licença | SIL Open Font License 1.1 (`OFL.txt` na mesma pasta) |
| Origem | Google Fonts |
| Tamanho | ~408 KB |

### Eixos variáveis

| Eixo | Mínimo | Padrão do arquivo | Máximo |
|---|---|---|---|
| `opsz` (tamanho óptico) | 12 | **96** | 96 |
| `wght` (peso) | 200 | **800** | 800 |
| `wdth` (largura) | 75 | **100** | 100 |

### Armadilha importante

O padrão embutido no arquivo é `opsz 96, wght 800, wdth 100`, ou seja, **ExtraBold em escala de display**. Se você carregar a fonte sem declarar eixos, tudo sai ExtraBold. Isso não é o comportamento esperado e não corresponde a nenhuma instância nomeada.

**Sempre declare `font-variation-settings` explicitamente.**

### Instâncias nomeadas

Todas em `opsz 14, wdth 100`:

| Nome | `wght` |
|---|---|
| ExtraLight | 200 |
| Light | 300 |
| Regular | 400 |
| Medium | 500 |
| SemiBold | 600 |
| Bold | 700 |
| ExtraBold | 800 |

Variantes Condensed (`wdth 75`) e SemiCondensed (aproximadamente `wdth 87`) existem no eixo de largura e nos pesos estáticos do pacote completo do Google Fonts. Não estão versionadas aqui.

### Peso usado no manual

Os títulos grandes do manual de identidade aparentam ser **Bold (700) ou SemiBold (600)**. Isso é leitura visual do PDF, não confirmação. O manual não declara o peso em texto. Se a peça for institucional e o peso importar, confirme no arquivo `.ai` em `assets/editaveis/`.

## Fonte secundária: Montserrat

Uso: corpo de texto, textos de apoio, legendas.

| Campo | Valor |
|---|---|
| Família | Montserrat |
| Arquivos | `Montserrat-VariableFont_wght.ttf` e `Montserrat-Italic-VariableFont_wght.ttf` |
| Versão | 9.000 |
| Licença | SIL Open Font License 1.1 |
| Origem | Google Fonts |
| Tamanho | ~689 KB (roman) e ~701 KB (itálico) |

### Eixos variáveis

| Eixo | Mínimo | Padrão do arquivo | Máximo |
|---|---|---|---|
| `wght` | 100 | **100** | 900 |

O padrão do arquivo é Thin (100). Também aqui, declare o peso explicitamente.

Pesos estáticos disponíveis no pacote completo do Google Fonts, com itálico correspondente para cada: Thin 100, ExtraLight 200, Light 300, Regular 400, Medium 500, SemiBold 600, Bold 700, ExtraBold 800, Black 900.

## O que está versionado aqui

Só as fontes variáveis, mais o `OFL.txt` de cada família. O pacote original tinha 126 arquivos `.ttf` estáticos, ruído desnecessário em um repositório feito para leitura por LLM. As variáveis cobrem toda a faixa de peso.

Para recuperar os estáticos:

- https://fonts.google.com/specimen/Bricolage+Grotesque
- https://fonts.google.com/specimen/Montserrat

## Regra de uso

| Elemento | Fonte | Peso sugerido |
|---|---|---|
| Título de peça, H1, H2 | Bricolage Grotesque | 700 |
| Subtítulo, H3 | Bricolage Grotesque | 600 |
| Corpo de texto | Montserrat | 400 |
| Destaque dentro do corpo | Montserrat | 600 |
| Legenda, nota de rodapé | Montserrat | 400, tamanho menor |
| Número em destaque (preço, milhas) | Bricolage Grotesque | 700 |

Nunca usar fonte com serifa ou cursiva em material da Travel Up. É diretriz explícita do briefing original.

## CSS pronto

Com os arquivos locais deste repositório:

```css
@font-face {
  font-family: 'Bricolage Grotesque';
  src: url('../assets/fontes/bricolage-grotesque/BricolageGrotesque-VariableFont_opsz,wdth,wght.ttf') format('truetype-variations');
  font-weight: 200 800;
  font-stretch: 75% 100%;
  font-display: swap;
}

@font-face {
  font-family: 'Montserrat';
  src: url('../assets/fontes/montserrat/Montserrat-VariableFont_wght.ttf') format('truetype-variations');
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}

@font-face {
  font-family: 'Montserrat';
  src: url('../assets/fontes/montserrat/Montserrat-Italic-VariableFont_wght.ttf') format('truetype-variations');
  font-weight: 100 900;
  font-style: italic;
  font-display: swap;
}

:root {
  --tu-fonte-titulo: 'Bricolage Grotesque', system-ui, sans-serif;
  --tu-fonte-texto:  'Montserrat', system-ui, sans-serif;
}

h1, h2, h3 {
  font-family: var(--tu-fonte-titulo);
  font-variation-settings: 'opsz' 14, 'wght' 700, 'wdth' 100;
}

body {
  font-family: var(--tu-fonte-texto);
  font-variation-settings: 'wght' 400;
}
```

Via Google Fonts, se a peça for uma página pública e você não quiser servir os arquivos:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wdth,wght@12..96,75..100,200..800&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
```

A URL do Google Fonts acima segue a sintaxe documentada da API v2 e é coerente com os eixos lidos dos arquivos, mas não foi testada em navegador. Verifique se renderiza antes de publicar.
