# Briefing original — Travel Up

Transcrição integral do documento `Shark Briefing - Travel UP.pdf` (2 páginas), o briefing entregue ao estúdio que criou a identidade. Serve como registro da intenção original da marca.

Cliente: Paula Fortini — Travel UP.

## 1. Identidade da fundadora

- Nome: Paula Fortini
- Experiência: iniciando no mercado de milhas, com algumas emissões de passagens.
- Objetivo: monetizar no mercado das milhas.

## 2. Personalidade e estilo

- Gosta de ideias diretas, minimalistas e práticas.
- Valores: confiança e praticidade.
- Se fosse uma pessoa: confiável, prática, objetiva e amigável (como alguém que conversa com todos em uma mesa de bar).

## 3. Proposta de valor

- Transmitir praticidade, confiança e facilidade.
- Público-alvo: pessoas de médio/alto padrão que desejam viajar mais barato, em busca das melhores rotas.

## 4. Diretrizes visuais

- Estilo minimalista e elegante.
- Paleta de cores: evitar cores muito fortes e quentes para não remeter a varejo.
- Tipografia: sem serifa, sem fonte cursiva. Busca uma tipografia que funcione de forma isolada e que tenha um símbolo que represente a marca.
- Inspirações: referência na identidade da Boca Rosa.

## 5. Concorrência

- Qualquer pessoa ou empresa que emite passagens.

## 6. Aplicações da marca

- Presença majoritariamente digital.
- Materiais: apresentação comercial, card para WhatsApp, cartão de visitas, brindes.

## 7. Conceito visual

- Minimalismo, elegância e neutralidade.
- Priorizar liberdade visual e versatilidade da marca.

## 8. Pesquisas e inspirações

- Paula buscará referências visuais para auxiliar no processo criativo.

## Notas de leitura

Duas diretrizes do briefing explicam decisões da identidade final e devem ser respeitadas em qualquer material novo:

1. **"Evitar cores muito fortes e quentes para não remeter a varejo"** é a razão da paleta ser inteiramente fria (azuis e um cinza-azulado). Não introduzir vermelho, laranja, amarelo ou verde saturado em peça da marca, nem como cor de destaque ou de botão.

2. **"Tipografia que funcione de forma isolada e que tenha um símbolo que represente a marca"** é a razão da submarca existir: o bloco `up` com o avião funciona sozinho, sem o wordmark completo.
