# Manifesto e posicionamento — Travel Up

Fonte: manual de identidade da marca (`TRAVEL UP - MANUAL DE IDENTIDADE.pdf`, 13 páginas) e briefing de criação. Texto transcrito, não reescrito.

## O que é

Viajar com inteligência é mais do que economizar, é fazer escolhas práticas, confiáveis e com estilo. A Travel UP nasce com esse propósito: facilitar o acesso a viagens mais baratas através do uso estratégico de milhas, sem complicação e com total transparência.

Idealizada por Paula Fortini, a Travel UP foi criada para quem quer viver o mundo com leveza, sem abrir mão do bom gosto e da praticidade.

## Posicionamento

A Travel UP se posiciona como a aliada de pessoas de médio e alto padrão que querem economizar em passagens, mas sem perder tempo com informações confusas ou técnicas demais.

Implicações práticas desse posicionamento:

- O cliente tem dinheiro. O argumento não é "é barato", é "é inteligente".
- O cliente não quer estudar milhas. Ele quer o resultado, não o método.
- Tempo é parte do valor entregue, não só o desconto.
- Transparência é diferencial competitivo em um mercado onde ela é rara.

## Tom de voz

- Direta ao ponto, sem perder a empatia.
- Linguagem amigável, inteligente e descomplicada.

Como isso se traduz em texto:

| Faça | Não faça |
|---|---|
| "Essa emissão sai por R$ 1.840. A tarifa paga está R$ 3.200." | "Aproveite nossa condição imperdível!" |
| Explicar o termo na primeira vez que usar | Assumir que o cliente sabe o que é milheiro, CPM, balcão |
| Falar em reais, e em milhas só quando ajuda | Encher o texto de siglas de programa |
| Encerrar com o próximo passo claro | Encerrar com urgência artificial |

Evitar: linguagem de varejo, superlativo, contagem regressiva, "últimas vagas", emoji em excesso, promessa de economia sem número.

## Personalidade da marca

Confiável, minimalista, objetiva e amigável.

Do briefing original, a definição de como a marca se comportaria se fosse pessoa: "confiável, prática, objetiva e amigável, como alguém que conversa com todos em uma mesa de bar".

Valores declarados: confiança e praticidade.

## Público-alvo

Pessoas de médio e alto padrão que desejam viajar mais barato, em busca das melhores rotas.

## Concorrência

Qualquer pessoa ou empresa que emite passagens. O mercado é pulverizado e pouco profissionalizado, o que faz da consistência de marca um diferencial real e não só estética.

## Aplicações previstas da marca

Presença majoritariamente digital. Materiais mapeados no briefing:

- Apresentação comercial
- Card para WhatsApp
- Cartão de visitas
- Brindes

## Conceito visual

Minimalismo, elegância e neutralidade. A identidade foi construída priorizando liberdade visual e versatilidade, o que explica a existência de 19 variações de logo e submarca em vez de uma versão única fechada.
